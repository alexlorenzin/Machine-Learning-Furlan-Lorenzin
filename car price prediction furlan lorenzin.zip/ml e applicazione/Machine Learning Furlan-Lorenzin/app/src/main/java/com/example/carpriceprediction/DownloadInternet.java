package com.example.carpriceprediction;

import android.app.ProgressDialog;
import android.os.AsyncTask;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class DownloadInternet extends AsyncTask<URL, Void, String> {

    final ProgressDialog dialog = new ProgressDialog(MainActivity.activity);

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        dialog.setMessage("Downloading...");
        dialog.show();
    }

    @Override
    protected String doInBackground(URL... url) {

        String str = "";
        // Create the urlConnection
        try {

            HttpURLConnection urlConnection = (HttpURLConnection) url[0].openConnection();
            urlConnection.setRequestProperty("Content-Type", "application/json");
            InputStream inputStream = new BufferedInputStream(urlConnection.getInputStream());
            str = convertInputStreamToString(inputStream);

        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return str;
    }

    @Override
    protected void onPostExecute(String str) {
        super.onPostExecute(str);
        dialog.dismiss();

        JSONObject strJson = null;
        try {
            strJson = new JSONObject(str);
            double prediction = strJson.getDouble("prediction");

            //cambiare l'imagine
            AggiornaView(prediction);

        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    private String convertInputStreamToString(InputStream inputStream) {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder sb = new StringBuilder();
        String line;
        try {
            while ((line = bufferedReader.readLine()) != null) {
                sb.append(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }

    private void AggiornaView(double prediction)
    {
        MainActivity.activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                int predizione = (int)prediction;
                MainActivity.txtIdPredictionResult.setText(String.valueOf(predizione));
            }
        });
    }
}
