package com.example.carpriceprediction;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    static Activity activity;
    EditText txtIdIP;
    EditText txtIdYear;
    EditText txtIdPresentPrice;
    EditText txtIdKmsDriven;
    Button btnPredict;
    public static TextView txtIdPredictionResult;

    String indirizzoIP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        activity = this;
        txtIdIP = findViewById(R.id.idIP);
        txtIdYear = findViewById(R.id.idYear);
        txtIdPresentPrice = findViewById(R.id.idPresentPrice);
        txtIdKmsDriven = findViewById(R.id.idKmsDriven);
        btnPredict = findViewById(R.id.btnPredict);
        txtIdPredictionResult = findViewById(R.id.idPredictionResult);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);


    }


    public void RichiamaApi(View view)
    {
        URL url = null;
        indirizzoIP = txtIdIP.getText().toString();
        try {
            url = new URL("http://"+indirizzoIP+":5000/search?Year="+txtIdYear.getText()+"&Present_Price="+
                    txtIdPresentPrice.getText()+"&Kms_Driven="+txtIdKmsDriven.getText());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        new DownloadInternet().execute(url);
    }

}