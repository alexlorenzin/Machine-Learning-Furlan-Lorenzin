from flask import Flask, request, jsonify
import ml

app = Flask(__name__)

@app.route("/")
def hello():
    return "Hello, World!"

@app.route('/search')
def search():
    year = request.args.get('Year')
    presentPrice = request.args.get('Present_Price')
    kmsDriven = request.args.get('Kms_Driven')
    
    json = {"prediction":ml.calcolaPredizione(ml.calcolaDFtest([year,presentPrice,kmsDriven]))[0]}
    return jsonify(json)


if __name__ == "__main__":
    app.run(host="172.20.10.4")#mettere il mio pc personale

