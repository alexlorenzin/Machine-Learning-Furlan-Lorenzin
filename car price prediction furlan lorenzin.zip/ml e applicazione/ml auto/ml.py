import pandas as pd
#import numpy as np

from sklearn import linear_model


#lettura e creazione del dataset
df_train = pd.read_csv("cars_train.csv")
#df_test = pd.read_csv("cars_test.csv")


#rimuovo le features ininfluenti 
df_train = df_train.drop(['Fuel_Type','Seller_Type','Transmission','Owner'], axis=1)
#df_test = df_test.drop(['Fuel_Type','Seller_Type','Transmission','Owner'], axis=1)



#aggiungo una feature ( present price * kilometres drived)
df_train['PPoKD'] = df_train['Present_Price'] * df_train['Kms_Driven']
#df_test['PPoKD'] = df_test['Present_Price'] * df_test['Kms_Driven']

X_train=df_train[['Year','Present_Price','Kms_Driven','PPoKD']]
Y_train=df_train['Selling_Price']

#X_test = df_test[['Year','Present_Price','Kms_Driven','PPoKD']]
#print (X_test)
#Y_test = df_test['Selling_Price']


lr = linear_model.LinearRegression()
lr.fit(X_train,Y_train)


#Y_pred = lr.predict(X_test)
#accuracy = round(lr.score(X_train,Y_train)*100,2)
#print("accuracy: ")
#print (accuracy)


#creo un dataframe per i coefficienti dei dati precedenti 
#coeffs = pd.DataFrame(lr.coef_, X_train.columns, columns=['Coefficiente'])
#print(coeffs)


#creo e stampo un df per valore attuale e del probabile valore futuro



#predictions = lr.predict(array)

#Prices = pd.DataFrame({'Attuale':Y_test[0],'Predizione':predictions})

#print (Prices)

def calcolaDFtest(array):
    year = array[0]
    presentPrice = int(array[1])
    kmsDriven = int(array[2])
    ppokd = presentPrice * kmsDriven
    array = ((pd.DataFrame({'Year':[year],'Present_Price':[presentPrice],'Kms_Driven':[kmsDriven],'PPoKD':[ppokd]}))).reset_index()
    #array['PPoKD'] = presentPrice * kmsDriven
    array = array.drop(['index'], axis=1)
    return array


def calcolaPredizione(dfTest):
    predictions = lr.predict(dfTest)
    return predictions
